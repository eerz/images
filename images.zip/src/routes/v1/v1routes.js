module.exports = (app, globe) => {
  require("./relational/addElement")(app, globe);
};
